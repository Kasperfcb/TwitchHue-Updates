"""Send Bang Chaos events to TwitchHue on the same computer."""

import asyncio
import json
import os
from contextlib import suppress
from pathlib import Path

from aiohttp import ClientError, ClientSession, ClientTimeout


class HueEffects:
    def __init__(self, config):
        self.auto = config is None
        config = config if isinstance(config, dict) else {}
        self.token = str(config.get('token') or '').strip()
        self.port = config.get('port', 18765)
        self.queue = asyncio.Queue(maxsize=10)
        if self.token and (type(self.port) is not int or not 1 <= self.port <= 65535):
            print('TwitchHue: ugyldig port. Lyseffekter er slået fra.')
            self.token = ''

    def handle_event(self, message):
        if not self.auto and not self.token:
            return
        fallback = None
        if message['type'] == 'levelup':
            level = message.get('lvl')
            effect = f'level-{level}' if level in range(1, 7) else 'green'
            fallback = 'green' if effect != 'green' else None
        elif message['type'] == 'event':
            label = message.get('label', '')
            if label == 'NY FØLGER':
                effect = 'blink'
            elif label.startswith('NY SUB'):
                effect = 'sub'
            elif label.endswith((' GAVESUB', ' GAVESUBS')):
                effect = 'gift'
            elif label.startswith('RAID · '):
                effect = 'raid'
            elif label.endswith(' BITS'):
                effect = 'bits'
            else:
                return
        else:
            return
        try:
            self.queue.put_nowait((effect, fallback))
        except asyncio.QueueFull:
            print(f'TwitchHue: køen er fuld. Springer {effect} over.')

    async def run(self, app):
        if not self.auto and not self.token:
            yield
            return
        async with ClientSession(timeout=ClientTimeout(total=2)) as session:
            worker = asyncio.create_task(self.send_effects(session))
            try:
                yield
            finally:
                worker.cancel()
                with suppress(asyncio.CancelledError):
                    await worker

    def settings(self):
        if not self.auto:
            return self.token, self.port
        folder = Path(os.environ.get('APPDATA') or (Path.home() / '.config'))
        config_file = folder / 'HueTwitchController' / 'config.json'
        try:
            config = json.loads(config_file.read_text(encoding='utf-8'))
        except (OSError, ValueError):
            return '', 18765
        if not isinstance(config, dict):
            return '', 18765
        return config.get('access_token'), config.get('port', 18765)

    async def send_effects(self, session):
        while True:
            effect, fallback = await self.queue.get()
            try:
                token, port = self.settings()
                if not isinstance(token, str) or not token or type(port) is not int or not 1 <= port <= 65535:
                    print('TwitchHue: åbn TwitchHue og vælg demo eller par din Bridge.')
                    continue
                for candidate in (effect, fallback) if fallback else (effect,):
                    async with session.get(
                        f'http://127.0.0.1:{port}/trigger',
                        params={'effect': candidate},
                        headers={'X-Hue-Twitch-Token': token},
                        allow_redirects=False,
                    ) as response:
                        if response.status == 404 and candidate != fallback:
                            continue
                        if response.status not in (202, 204, 404):
                            print(f'TwitchHue: {candidate} blev afvist (HTTP {response.status}).')
                        break
            except (ClientError, TimeoutError, ValueError):
                print(f'TwitchHue: kunne ikke sende {effect}. Kontrollér at TwitchHue kører.')
            finally:
                self.queue.task_done()
