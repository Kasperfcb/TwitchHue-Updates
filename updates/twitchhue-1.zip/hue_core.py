"""Hue Twitch Controller core: no third-party dependencies, Python 3.10+."""
from __future__ import annotations

import copy
import hashlib
import hmac
import http.client
import ipaddress
import json
import math
import os
import queue
import re
import secrets
import ssl
import threading
import time
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit, parse_qs
from urllib.request import urlopen

APP_NAME = 'HueTwitchController'
PORT = 18765
EFFECT_TYPES = ('Farve', 'Blink', 'Blink i valgt farve', 'Regnbue', 'Sluk',
                'Varm hvid', 'Tilfældig farve', 'Hue-scene')


def default_effects():
    return {
        'red': dict(name='Rødt lys', kind='Farve', color='#FF1744', duration=8, brightness=90, cooldown=15, enabled=True),
        'green': dict(name='Grønt lys', kind='Farve', color='#00E676', duration=8, brightness=90, cooldown=15, enabled=True),
        'blue': dict(name='Blåt lys', kind='Farve', color='#2979FF', duration=8, brightness=90, cooldown=15, enabled=True),
        'blink': dict(name='Blink', kind='Blink', color='#FFFFFF', duration=5, brightness=90, cooldown=25, enabled=True),
        'rainbow': dict(name='Regnbue', kind='Regnbue', color='#FF0000', duration=7, brightness=85, cooldown=30, enabled=True),
        'off': dict(name='Sluk kort', kind='Sluk', color='#FFFFFF', duration=5, brightness=90, cooldown=30, enabled=True),
        'random': dict(name='Overrask mig', kind='Tilfældig farve', color='#FF0000', duration=8, brightness=90, cooldown=15, enabled=True),
        'warm': dict(name='Varm hvid', kind='Varm hvid', color='#FFF1C1', duration=8, brightness=70, cooldown=15, enabled=True),
    }


def config_path():
    folder = Path(os.environ.get('APPDATA') or (Path.home() / '.config')) / APP_NAME
    folder.mkdir(parents=True, exist_ok=True)
    return folder / 'config.json'


def new_config():
    return dict(ip='', app_key='', certificate_sha256='', access_token=secrets.token_urlsafe(32),
                selected_ids=[], real_selected_ids=[], demo_mode=False, port=PORT, effects=default_effects())


def load_config(path=None):
    p = Path(path) if path else config_path()
    obj = new_config()
    if p.exists():
        data = json.loads(p.read_text(encoding='utf-8'))
        if isinstance(data, dict):
            for k in ('ip', 'app_key', 'certificate_sha256', 'access_token', 'selected_ids', 'real_selected_ids', 'demo_mode', 'port'):
                if k in data:
                    obj[k] = data[k]
            if isinstance(data.get('effects'), dict):
                obj['effects'] = data['effects']
    if not isinstance(obj['access_token'], str) or len(obj['access_token']) < 32:
        obj['access_token'] = secrets.token_urlsafe(32)
    if not isinstance(obj['selected_ids'], list):
        obj['selected_ids'] = []
    if not isinstance(obj['real_selected_ids'], list):
        obj['real_selected_ids'] = []
    obj['demo_mode'] = obj.get('demo_mode') is True
    return obj


def save_config(cfg, path=None):
    p = Path(path) if path else config_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_name(p.name + '.tmp')
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
    os.replace(tmp, p)


def check_local_ip(ip):
    try:
        addr = ipaddress.ip_address(ip.strip())
        if addr.version != 4 or not addr.is_private or addr.is_loopback or addr.is_link_local:
            raise ValueError()
        return str(addr)
    except ValueError:
        raise ValueError('Indtast en gyldig privat IPv4-adresse, fx 192.168.0.50') from None


def discover_bridge():
    # Optional official online discovery. Manual IP works with no cloud service.
    with urlopen('https://discovery.meethue.com/', timeout=6) as response:
        data = json.loads(response.read(65536))
    for item in data:
        ip = item.get('internalipaddress', '')
        try:
            return check_local_ip(ip)
        except ValueError:
            pass
    raise RuntimeError('Ingen Hue Bridge fundet. Indtast IP-adressen manuelt fra Hue-appen.')


class HueError(Exception):
    pass


class HueBridge:
    def __init__(self, ip, app_key='', fingerprint=''):
        self.ip = check_local_ip(ip)
        self.app_key = app_key
        self.fingerprint = fingerprint.lower().replace(':', '')
        self._last_put = 0.0  # Hue recommends a ~100 ms gap between per-light commands.

    def _request(self, method, path, body=None, pairing=False):
        # Hue Bridge certificate is self-signed. Pin the certificate fingerprint when pairing,
        # and verify it *before* sending the API key on every future connection.
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        conn = http.client.HTTPSConnection(self.ip, 443, timeout=5, context=ctx)
        try:
            conn.connect()
            cert = conn.sock.getpeercert(binary_form=True)
            if not cert:
                raise HueError('Hue Bridge returnerede intet TLS-certifikat')
            fp = hashlib.sha256(cert).hexdigest()
            if not pairing and (not self.fingerprint or not hmac.compare_digest(fp, self.fingerprint)):
                raise HueError('Hue Bridge-certifikatet matcher ikke. Par bridgen igen via knappen.')
            headers = {'Accept': 'application/json'}
            if not pairing:
                if not self.app_key:
                    raise HueError('Par først din Hue Bridge')
                headers['hue-application-key'] = self.app_key
            payload = None
            if body is not None:
                payload = json.dumps(body, separators=(',', ':')).encode('utf-8')
                headers['Content-Type'] = 'application/json'
            conn.request(method, path, body=payload, headers=headers)
            res = conn.getresponse()
            data = res.read(2_000_000)
            if res.status >= 400:
                raise HueError(f'Bridge returnerede HTTP {res.status}')
            obj = json.loads(data) if data else {}
            if isinstance(obj, dict) and obj.get('errors'):
                raise HueError(str(obj['errors'][0].get('description', obj['errors'][0])))
            return obj, fp
        except (OSError, TimeoutError, ssl.SSLError, ValueError) as e:
            raise HueError(f'Kan ikke kommunikere med Hue Bridge: {e}') from e
        finally:
            conn.close()

    def pair(self, timeout=32, retry=1.8, stop=None):
        end = time.monotonic() + timeout
        while time.monotonic() < end:
            if stop and stop.is_set():
                raise HueError('Parring afbrudt')
            response, fingerprint = self._request('POST', '/api',
                {'devicetype': 'hue_twitch_controller#stream_pc'}, pairing=True)
            if not isinstance(response, list) or not response:
                raise HueError('Uventet svar fra Hue Bridge under parring')
            item = response[0]
            if 'success' in item and item['success'].get('username'):
                key = item['success']['username']
                # Verify authenticated v2 endpoint before committing credentials.
                test = HueBridge(self.ip, key, fingerprint)
                test.lights()
                return key, fingerprint
            error = item.get('error', {})
            if error.get('type') != 101:
                raise HueError(error.get('description', 'Ukendt parringsfejl'))
            time.sleep(min(retry, max(0, end - time.monotonic())))
        raise HueError('Der kom ikke svar fra knappen inden 32 sekunder. Prøv igen.')

    def lights(self):
        lights, _ = self._request('GET', '/clip/v2/resource/light')
        devices, _ = self._request('GET', '/clip/v2/resource/device')
        device_names = {x.get('id'): x.get('metadata', {}).get('name', '') for x in devices.get('data', [])}
        result = []
        for light in lights.get('data', []):
            item = copy.deepcopy(light)
            owner = item.get('owner') or {}
            item['_display_name'] = (device_names.get(owner.get('rid'))
                                     or item.get('metadata', {}).get('name')
                                     or 'Pære ' + item['id'][:8])
            result.append(item)
        result.sort(key=lambda x: x['_display_name'].lower())
        return result

    def set_light(self, light_id, payload):
        if not re.fullmatch(r'[a-zA-Z0-9-]{4,80}', light_id):
            raise HueError('Ugyldigt pære-ID')
        gap = 0.11 - (time.monotonic() - self._last_put)
        if gap > 0:
            time.sleep(gap)
        self._last_put = time.monotonic()
        self._request('PUT', f'/clip/v2/resource/light/{light_id}', payload)

    def scenes(self):
        result, _ = self._request('GET', '/clip/v2/resource/scene')
        return result.get('data', [])


class DemoBridge:
    """Thread-safe virtual Hue bulbs; never contacts a network device."""
    _lock = threading.RLock()
    _template = (
        ('demo-1', 'Demo • Skrivebord'),
        ('demo-2', 'Demo • LED-strip'),
        ('demo-3', 'Demo • Baggrund'),
    )
    _states = None

    @classmethod
    def _ensure(cls):
        if cls._states is None:
            cls._states = {
                uid: {'id': uid, '_display_name': name, 'on': {'on': True},
                      'dimming': {'brightness': 55},
                      'color': {'xy': {'x': 0.33, 'y': 0.33}},
                      'color_temperature': {'mirek': 300, 'mirek_valid': True,
                                            'mirek_schema': {'mirek_minimum': 153, 'mirek_maximum': 500}},
                      '_preview_hex': '#FFE4B5'}
                for uid, name in cls._template}

    def __init__(self, ip='', app_key='', fingerprint=''):
        pass

    def lights(self):
        with self._lock:
            self._ensure()
            return copy.deepcopy(list(self._states.values()))

    def scenes(self):
        return [{
            'id': 'demo-sunset',
            'metadata': {'name': 'Solnedgang (demo)'},
            'actions': [
                {'target': {'rid': light_id, 'rtype': 'light'},
                 'action': {'on': {'on': True}, 'dimming': {'brightness': 65},
                            'color': {'xy': rgb_to_xy(color)}}}
                for (light_id, _), color in zip(self._template, ('#FF782E', '#DA408A', '#6C44FF'))
            ],
        }]

    def set_light(self, light_id, payload):
        with self._lock:
            self._ensure()
            if light_id not in self._states:
                raise HueError('Ukendt demo-pære')
            target = self._states[light_id]
            for field in ('on', 'dimming', 'color', 'color_temperature'):
                if field in payload:
                    target[field].update(copy.deepcopy(payload[field]))
            if 'color' in payload:
                target['color_temperature']['mirek_valid'] = False
                target['_preview_hex'] = xy_to_hex(target['color']['xy'])
            elif 'color_temperature' in payload:
                target['color_temperature']['mirek_valid'] = True
                target['_preview_hex'] = '#FFE4B5'


def xy_to_hex(xy):
    """Approximate xyY→sRGB only for the onscreen demo preview."""
    x, y = float(xy['x']), float(xy['y'])
    if y <= 0:
        return '#FFFFFF'
    X, Y, Z = x / y, 1.0, (1.0 - x - y) / y
    r = 1.656492 * X - 0.354851 * Y - 0.255038 * Z
    g = -0.707196 * X + 1.655397 * Y + 0.036152 * Z
    b = 0.051713 * X - 0.121364 * Y + 1.011530 * Z
    values = [max(0.0, v) for v in (r, g, b)]
    peak = max(values)
    if peak > 1:
        values = [v / peak for v in values]
    srgb = [12.92*v if v <= 0.0031308 else 1.055 * v ** (1 / 2.4) - 0.055 for v in values]
    return '#%02X%02X%02X' % tuple(round(min(1, max(0, v)) * 255) for v in srgb)


def rgb_to_xy(hex_color):
    if not re.fullmatch(r'#[0-9a-fA-F]{6}', hex_color):
        raise ValueError('Farve skal være i formatet #RRGGBB')
    channels = [int(hex_color[i:i + 2], 16) / 255 for i in (1, 3, 5)]
    r, g, b = [((x + .055) / 1.055) ** 2.4 if x > .04045 else x / 12.92 for x in channels]
    X = r * .664511 + g * .154324 + b * .162028
    Y = r * .283881 + g * .668433 + b * .047685
    Z = r * .000088 + g * .072310 + b * .986039
    total = X + Y + Z
    if total < 1e-9:
        raise ValueError('Sort er ikke en gyldig lyseffektfarve')
    return {'x': round(X / total, 5), 'y': round(Y / total, 5)}


def payload_for_restore(light):
    # Hue v2 reports mirek_valid=false outside color temperature mode.
    if not light.get('on', {}).get('on', False):
        return {'on': {'on': False}}
    body = {'on': {'on': True}}
    if 'brightness' in light.get('dimming', {}):
        body['dimming'] = {'brightness': light['dimming']['brightness']}
    ct = light.get('color_temperature') or {}
    xy = (light.get('color') or {}).get('xy')
    if ct.get('mirek_valid') and ct.get('mirek') is not None:
        body['color_temperature'] = {'mirek': ct['mirek']}
    elif isinstance(xy, dict) and 'x' in xy and 'y' in xy:
        body['color'] = {'xy': {'x': xy['x'], 'y': xy['y']}}
    return body


def validated_effect(effect):
    if effect.get('kind') not in EFFECT_TYPES:
        raise ValueError('Ukendt effekttype')
    if not re.fullmatch(r'#[0-9A-Fa-f]{6}', effect.get('color', '')):
        raise ValueError('Farven skal være #RRGGBB')
    for key, low, high in [('duration', 1, 60), ('brightness', 1, 100), ('cooldown', 0, 600)]:
        n = int(effect[key])
        if n < low or n > high:
            raise ValueError(f'{key} skal være mellem {low} og {high}')
        effect[key] = n
    effect['name'] = str(effect.get('name', '')).strip()[:45]
    if not effect['name']:
        raise ValueError('Navn mangler')
    effect['enabled'] = bool(effect.get('enabled', True))
    if effect['kind'] == 'Varm hvid':
        effect['kelvin'] = int(effect.get('kelvin') or 2500)
        if not 2000 <= effect['kelvin'] <= 6500:
            raise ValueError('Hvidtemperaturen skal være mellem 2000 og 6500 K')
    return effect


class EffectEngine:
    def __init__(self, config, logger=lambda text: None, bridge_factory=HueBridge, sleeper=time.sleep):
        self.config = config
        self.log = logger
        self.bridge_factory = bridge_factory
        self.sleep = sleeper
        self.jobs = queue.Queue(maxsize=10)
        self.lock = threading.Lock()
        self.cooldowns = {}
        self.stop = threading.Event()
        self.cancel_active = threading.Event()
        self.worker = threading.Thread(target=self._run, daemon=True, name='HueEffects')

    def start(self):
        self.worker.start()

    def enqueue(self, effect_id, bypass_cooldown=False):
        with self.lock:
            effect = self.config['effects'].get(effect_id)
            if effect and re.fullmatch(r'level-[1-6]', effect_id):
                if effect.get('inherit_level'):
                    return 404, 'Bruger fælles leveleffekt'
                if not effect.get('enabled', True) and not bypass_cooldown:
                    return 204, 'Dette level gør ingenting'
            if not effect or not effect.get('enabled', True):
                return 404, 'Effekten er slået fra'
            if not self.config.get('demo_mode') and (not self.config.get('app_key') or not self.config.get('certificate_sha256')):
                return 503, 'Hue Bridge er ikke parret'
            selected = self.config.get('selected_ids', [])
            target_key = 'demo_light_ids' if self.config.get('demo_mode') else 'light_ids'
            scene_key = 'demo_scene_id' if self.config.get('demo_mode') else 'scene_id'
            if effect['kind'] == 'Hue-scene' and not effect.get(scene_key):
                return 409, 'Vælg en Hue-scene til effekten'
            targets = effect.get(target_key)
            if isinstance(targets, list):
                selected = [light_id for light_id in selected if light_id in targets]
            if not selected:
                return 409, 'Vælg mindst én pære i programmet'
            now = time.monotonic()
            remaining = self.cooldowns.get(effect_id, 0) - now
            if remaining > 0 and not bypass_cooldown:
                return 429, f'Cooldown: {math.ceil(remaining)} sekunder'
            try:
                self.jobs.put_nowait((effect_id, copy.deepcopy(effect), list(selected),
                                      self.config['ip'], self.config['app_key'], self.config['certificate_sha256']))
            except queue.Full:
                return 429, 'Effektkøen er fuld'
            if not bypass_cooldown:
                self.cooldowns[effect_id] = now + int(effect.get('cooldown', 0))
            self.log(f"Modtaget: {effect['name']} (i kø: {self.jobs.qsize()})")
            return 202, f"Effekt '{effect['name']}' sat i kø"

    def cancel(self):
        self.cancel_active.set()
        cleared = 0
        while True:
            try:
                self.jobs.get_nowait()
                self.jobs.task_done()
                cleared += 1
            except queue.Empty:
                break
        self.log(f'Stop signal sendt. {cleared} ventende effekter fjernet.')

    def shutdown(self):
        self.stop.set()
        self.cancel()
        self.worker.join(timeout=6)

    def _wait(self, sec):
        until = time.monotonic() + max(0, sec)
        while time.monotonic() < until:
            if self.stop.is_set() or self.cancel_active.is_set():
                return False
            self.sleep(min(.15, until - time.monotonic()))
        return True

    def _run(self):
        while not self.stop.is_set():
            try:
                job = self.jobs.get(timeout=.2)
            except queue.Empty:
                continue
            try:
                self.cancel_active.clear()
                self._play(*job)
            except Exception as e:
                self.log('Fejl: ' + str(e))
            finally:
                self.jobs.task_done()

    def _play(self, effect_id, effect, selected, ip, key, fingerprint):
        bridge = (DemoBridge() if self.config.get('demo_mode') else self.bridge_factory(ip, key, fingerprint))
        all_lights = bridge.lights()
        chosen = [l for l in all_lights if l['id'] in selected]
        if not chosen:
            self.log('Ingen af de valgte pærer findes på Hue Bridge')
            return
        kind = effect['kind']
        if kind == 'Hue-scene':
            scene_key = 'demo_scene_id' if self.config.get('demo_mode') else 'scene_id'
            scene = next((item for item in bridge.scenes() if item['id'] == effect[scene_key]), None)
            if scene is None:
                raise HueError('Scenen findes ikke længere. Vælg en scene igen under Effekter.')
            selected_by_id = {light['id']: light for light in chosen}
            scene_payloads = {}
            for action in scene.get('actions', []):
                target = action.get('target', {})
                light_id = target.get('rid')
                if target.get('rtype') == 'light' and light_id in selected_by_id:
                    payload = {key: value for key, value in action.get('action', {}).items()
                               if key in ('on', 'dimming', 'color', 'color_temperature')
                               and key in selected_by_id[light_id]}
                    if payload:
                        scene_payloads[light_id] = payload
            if not scene_payloads:
                raise HueError('Scenen har ingen af de valgte pærer. Vælg pærer fra scenen under Effekter.')
            chosen = [selected_by_id[light_id] for light_id in scene_payloads]
        snapshots = {l['id']: payload_for_restore(l) for l in chosen}
        brightness = float(effect['brightness'])
        duration = int(effect['duration'])
        palette = ['#FF1744', '#FF9100', '#FFEA00', '#00E676', '#00B0FF', '#651FFF', '#E040FB']

        def send_color(color):
            xy = rgb_to_xy(color)
            count = 0
            for light in chosen:
                if 'color' not in light:
                    continue
                bridge.set_light(light['id'], {'on': {'on': True}, 'dimming': {'brightness': brightness},
                                               'color': {'xy': xy}})
                count += 1
            return count

        def send_on(value):
            for light in chosen:
                bridge.set_light(light['id'], {'on': {'on': value}})

        try:
            self.log(f"Kører: {effect['name']} ({len(chosen)} pærer)")
            if kind == 'Hue-scene':
                for light_id, payload in scene_payloads.items():
                    bridge.set_light(light_id, payload)
                self._wait(duration)
            elif kind == 'Farve':
                if send_color(effect['color']) == 0:
                    self.log('Ingen af de valgte pærer understøtter farver')
                self._wait(duration)
            elif kind == 'Tilfældig farve':
                import random
                send_color('#%06X' % random.randint(0, 0xFFFFFF))
                self._wait(duration)
            elif kind == 'Varm hvid':
                count = 0
                for light in chosen:
                    if 'color_temperature' in light:
                        schema = light.get('color_temperature', {}).get('mirek_schema', {})
                        low, high = schema.get('mirek_minimum', 153), schema.get('mirek_maximum', 500)
                        mirek = min(high, max(low, round(1_000_000 / int(effect.get('kelvin') or 2500))))
                        bridge.set_light(light['id'], {'on': {'on': True},
                            'dimming': {'brightness': brightness}, 'color_temperature': {'mirek': mirek}})
                        count += 1
                if count == 0:
                    self.log('Ingen af de valgte pærer understøtter farvetemperatur')
                self._wait(duration)
            elif kind == 'Sluk':
                send_on(False)
                self._wait(duration)
            elif kind in ('Blink', 'Blink i valgt farve'):
                ends = time.monotonic() + duration
                if kind == 'Blink i valgt farve':
                    chosen = [light for light in chosen if 'color' in light]
                    if send_color(effect['color']) == 0:
                        self.log('Ingen af de valgte pærer understøtter farver')
                        return
                    if not self._wait(.35):
                        return
                while time.monotonic() < ends and not self.stop.is_set() and not self.cancel_active.is_set():
                    send_on(False)
                    if not self._wait(.35):
                        break
                    send_on(True)
                    if not self._wait(.35):
                        break
            elif kind == 'Regnbue':
                ends = time.monotonic() + duration
                i = 0
                while time.monotonic() < ends and not self.stop.is_set() and not self.cancel_active.is_set():
                    send_color(palette[i % len(palette)])
                    i += 1
                    if not self._wait(.5):
                        break
        finally:
            errors = []
            for light in chosen:
                try:
                    bridge.set_light(light['id'], snapshots[light['id']])
                except Exception as e:
                    errors.append(f"{light['_display_name']}: {e}")
            if errors:
                self.log('Gendannelse kunne ikke fuldføres: ' + '; '.join(errors))
            else:
                self.log('Lyset er gendannet til tilstanden før effekten')


class LocalController:
    def __init__(self, engine, config, logger=lambda text: None):
        self.engine = engine
        self.config = config
        self.log = logger
        self.server = None
        self.thread = None

    def start(self):
        controller = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass  # Never log URLs, tokens or user input.

            def send_json(self, code, data):
                raw = json.dumps(data, ensure_ascii=False).encode('utf-8')
                self.send_response(code)
                self.send_header('Content-Type', 'application/json; charset=utf-8')
                self.send_header('Cache-Control', 'no-store')
                self.send_header('X-Content-Type-Options', 'nosniff')
                if code == 204:
                    self.end_headers()
                    return
                self.send_header('Content-Length', str(len(raw)))
                self.end_headers()
                self.wfile.write(raw)

            def do_GET(self):
                url = urlsplit(self.path)
                if url.path == '/health':
                    self.send_json(200, {'ok': True, 'name': APP_NAME})
                    return
                if url.path != '/trigger':
                    self.send_json(404, {'ok': False, 'message': 'Ukendt sti'})
                    return
                secret = self.headers.get('X-Hue-Twitch-Token', '')
                correct = controller.config['access_token']
                if not hmac.compare_digest(secret, correct):
                    self.send_json(401, {'ok': False, 'message': 'Manglende eller forkert adgangsnøgle'})
                    return
                args = parse_qs(url.query, keep_blank_values=True)
                effect_id = args.get('effect', [''])[0]
                if len(effect_id) > 32 or not re.fullmatch('[a-z0-9_-]+', effect_id):
                    self.send_json(400, {'ok': False, 'message': 'Ugyldigt effekt-ID'})
                    return
                code, message = controller.engine.enqueue(effect_id)
                self.send_json(code, {'ok': code == 202, 'message': message})

            def do_POST(self):
                self.send_json(405, {'ok': False, 'message': 'Kun GET understøttes'})

        self.server = ThreadingHTTPServer(('127.0.0.1', int(self.config['port'])), Handler)
        self.server.daemon_threads = True
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True, name='HueHttp')
        self.thread.start()
        self.log('Klar til at modtage lyseffekter')

    def stop(self):
        if self.server:
            self.server.shutdown()
            self.server.server_close()
            self.server = None
            if self.thread:
                self.thread.join(timeout=2)
