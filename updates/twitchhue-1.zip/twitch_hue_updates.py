"""Updates for the Bang Chaos edition. Only application files are replaced."""

import hashlib
import io
import json
import tempfile
from pathlib import Path
from urllib.request import urlopen
from zipfile import ZipFile


FEED = 'https://raw.githubusercontent.com/Kasperfcb/TwitchHue-Updates/main/'
VERSION_FILE = 'TwitchHue-version.txt'
FILES = ('HueTwitchController.pyw', 'hue_core.py', 'twitch_hue_updates.py', 'hue.py')
MAX_PACKAGE_BYTES = 2_000_000


def installed_version(folder):
    try:
        return int((folder / VERSION_FILE).read_text(encoding='ascii').strip())
    except FileNotFoundError:
        return 0


def check_update(folder):
    with urlopen(FEED + 'latest.json', timeout=6) as response:
        info = json.loads(response.read(8192))
    version = info['version']
    digest = info['sha256']
    if type(version) is not int or version < 1 or len(bytes.fromhex(digest)) != 32:
        raise ValueError('Opdateringslisten kunne ikke læses.')
    return info if version > installed_version(folder) else None


def install_update(folder, info):
    folder = Path(folder)
    version = info['version']
    if version <= installed_version(folder):
        return
    with urlopen(FEED + f'updates/twitchhue-{version}.zip', timeout=12) as response:
        package = response.read(MAX_PACKAGE_BYTES + 1)
    if len(package) > MAX_PACKAGE_BYTES or hashlib.sha256(package).hexdigest() != info['sha256']:
        raise ValueError('Den hentede opdatering kunne ikke kontrolleres.')
    with ZipFile(io.BytesIO(package)) as archive:
        entries = archive.infolist()
        if (len(entries) != len(FILES) or {entry.filename for entry in entries} != set(FILES)
                or sum(entry.file_size for entry in entries) > MAX_PACKAGE_BYTES):
            raise ValueError('Opdateringen indeholder uventede filer.')
        contents = {name: archive.read(name) for name in FILES}
    for name, content in contents.items():
        compile(content, name, 'exec')

    # The version is written last. On a failed write, restore files already replaced.
    targets = {folder / name: contents[name] for name in FILES if name != 'hue.py'}
    targets[folder.parent / 'hue.py'] = contents['hue.py']
    targets[folder / VERSION_FILE] = f'{version}\n'.encode('ascii')
    with tempfile.TemporaryDirectory(prefix='.update-', dir=folder.parent) as tmp:
        staging = Path(tmp)
        replaced = []
        originals = {target: target.read_bytes() if target.exists() else None for target in targets}
        try:
            for index, (target, content) in enumerate(targets.items()):
                pending = staging / str(index)
                pending.write_bytes(content)
                pending.replace(target)
                replaced.append(target)
        except OSError:
            for index, target in enumerate(reversed(replaced)):
                previous = originals[target]
                if previous is None:
                    target.unlink(missing_ok=True)
                else:
                    pending = staging / f'restore-{index}'
                    pending.write_bytes(previous)
                    pending.replace(target)
            raise
