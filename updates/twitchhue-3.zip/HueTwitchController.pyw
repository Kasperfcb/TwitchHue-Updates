"""Hue Twitch Controller – Windows GUI, Python 3.10+, no runtime dependencies."""
from __future__ import annotations

import copy
import os
import queue
import re
import threading
from pathlib import Path
from uuid import uuid4
from urllib.request import Request, urlopen
from urllib.error import HTTPError
import tkinter as tk
from tkinter import colorchooser, messagebox, ttk
from urllib.parse import quote

from hue_core import (EffectEngine, HueBridge, HueError, DemoBridge, LocalController, check_local_ip,
                      config_path, discover_bridge, load_config, save_config, validated_effect,
                      EFFECT_TYPES, default_effects)
from twitch_hue_updates import VERSION_FILE, check_update, install_update, installed_version

BG, PANEL, FIELD = '#111827', '#1b2436', '#26324a'
FG, MUTED, ACCENT, PINK = '#ffffff', '#B9C2CF', '#2DD4BF', '#EF9BC2'
BANG_EVENTS = {
    'blink': 'Ny følger',
    'green': 'Alle Chaos-levels',
    **{f'level-{level}': f'Chaos-level {level}' for level in range(1, 7)},
    'sub': 'Ny sub',
    'gift': 'Gavesub',
    'raid': 'Raid',
    'bits': 'Bits',
}


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.bang_chaos = os.environ.get('BANG_CHAOS_HUE') == '1'
        self.title('Bang Chaos · Lys' if self.bang_chaos else 'Hue Twitch Controller • Windows')
        self.geometry('1000x720' if self.bang_chaos else '1070x855')
        self.minsize(*(870, 650) if self.bang_chaos else (900, 780))
        self.configure(background=BG)
        self.config_data = load_config()
        if self.bang_chaos:
            effects = self.config_data['effects']
            for key, name in BANG_EVENTS.items():
                template = 'blink' if key == 'blink' else 'green'
                effects.setdefault(key, {**default_effects()[template], 'name': name,
                                         'enabled': key in ('blink', 'green'),
                                         'inherit_level': key.startswith('level-')})
        self.events = queue.Queue()
        self.lights = []
        self.effect_id = None
        self.busy = False
        self.update_running = False
        self.update_info = None
        self.install_folder = Path(__file__).resolve().parent
        self.updates_available = self.bang_chaos and (self.install_folder / VERSION_FILE).is_file()
        self.demo_render_state = None
        self.engine = EffectEngine(self.config_data, self.log)
        self.controller = LocalController(self.engine, self.config_data, self.log)
        self._theme()
        self._render()
        self.engine.start()
        try:
            self.controller.start()
        except Exception as e:
            messagebox.showerror('Lokal server', f'Kunne ikke starte den lokale HTTP-server: {e}')
            self.log('FEJL: HTTP-serveren kunne ikke starte: ' + str(e))
        self._refresh_demo_preview()
        self.after(120, self._poll_events)
        self.protocol('WM_DELETE_WINDOW', self._exit)
        self.log('Lysvinduet er åbent.')
        if self.config_data.get('app_key') or self.config_data.get('demo_mode'):
            self.after(300, self.refresh_lights)
        if self.updates_available:
            self.after(800, lambda: self.check_for_updates(quiet=True))

    def _theme(self):
        style = ttk.Style(self)
        style.theme_use('clam')
        style.configure('.', font=('Segoe UI', 10), background=BG, foreground=FG)
        style.configure('TFrame', background=BG)
        style.configure('Panel.TFrame', background=PANEL)
        style.configure('TLabel', background=BG, foreground=FG)
        style.configure('Panel.TLabel', background=PANEL, foreground=FG)
        style.configure('Muted.TLabel', background=BG, foreground=MUTED)
        style.configure('Title.TLabel', background=BG, foreground=FG, font=('Segoe UI Semibold', 22))
        style.configure('Section.TLabel', background=BG, foreground=PINK, font=('Segoe UI Semibold', 14))
        style.configure('TButton', padding=(12, 9), background=FIELD, foreground=FG, relief='flat')
        style.map('TButton', background=[('active', '#365070')])
        style.configure('Accent.TButton', background=ACCENT, foreground='#101d24', font=('Segoe UI Semibold', 10))
        style.map('Accent.TButton', background=[('active', '#a1f9e5')])
        style.configure('TEntry', fieldbackground=FIELD, foreground=FG, insertcolor=FG, padding=7)
        style.configure('TCombobox', fieldbackground=FIELD, background=FIELD, foreground=FG, arrowcolor=FG, padding=6)
        style.map('TCombobox', fieldbackground=[('readonly', FIELD)], foreground=[('readonly', FG)])
        style.configure('TNotebook', background=BG, borderwidth=0)
        style.configure('TNotebook.Tab', padding=(19, 12), background=PANEL, foreground=MUTED)
        style.map('TNotebook.Tab', background=[('selected', FIELD)], foreground=[('selected', ACCENT)])
        style.configure('Treeview', background=PANEL, foreground=FG, fieldbackground=PANEL, rowheight=33, borderwidth=0)
        style.map('Treeview', background=[('selected', '#29475d')], foreground=[('selected', FG)])
        style.configure('Treeview.Heading', background=FIELD, foreground=FG, padding=8, relief='flat')
        style.configure('TCheckbutton', background=BG, foreground=FG)
        style.map('TCheckbutton', background=[('active', BG)], foreground=[('active', FG)])
        style.configure('TSpinbox', fieldbackground=FIELD, foreground=FG, arrowsize=12)

    def _render(self):
        header = ttk.Frame(self, padding=(22, 15))
        header.pack(fill='x')
        ttk.Label(header, text='Bang Chaos · Lys' if self.bang_chaos else 'Hue Twitch Controller',
                  style='Title.TLabel').pack(side='left')
        self.status_var = tk.StringVar(value='● Klar til opsætning')
        ttk.Label(header, textvariable=self.status_var, style='Muted.TLabel').pack(side='right', padx=12)
        if self.updates_available:
            self.update_button = ttk.Button(header, text='Søg efter opdatering', command=self.update_clicked)
            self.update_button.pack(side='right')
            ttk.Label(header, text=f'Version {installed_version(self.install_folder)}',
                      style='Muted.TLabel').pack(side='right', padx=(8, 12))
        subtitle = ('Lys til nye følgere og levelskift.' if self.bang_chaos else
                    'Philips Hue + Twitch kanalpoint • lokal integration med Streamer.bot')
        ttk.Label(self, text=subtitle,
                  style='Muted.TLabel').pack(anchor='w', padx=24, pady=(0, 13))
        self.tabs = ttk.Notebook(self)
        self.tabs.pack(fill='both', expand=True, padx=21, pady=8)
        self.connection_tab = ttk.Frame(self.tabs, padding=20)
        self.lights_tab = ttk.Frame(self.tabs, padding=20)
        self.effects_tab = ttk.Frame(self.tabs, padding=20)
        self.streamer_tab = ttk.Frame(self.tabs, padding=20)
        self.log_tab = ttk.Frame(self.tabs, padding=20)
        tabs = [(self.connection_tab, 'Hue Bridge'), (self.lights_tab, 'Pærer'),
                (self.effects_tab, 'Effekter')]
        if not self.bang_chaos:
            tabs.append((self.streamer_tab, 'Streamer.bot'))
        for tab, title in [*tabs, (self.log_tab, 'Log')]:
            self.tabs.add(tab, text=title)
        self._connection_ui()
        self._lights_ui()
        self._effects_ui()
        if not self.bang_chaos:
            self._streamer_ui()
        self._log_ui()

    def _section(self, parent, name, description):
        ttk.Label(parent, text=name, style='Section.TLabel').pack(anchor='w', pady=(0, 7))
        ttk.Label(parent, text=description, style='Muted.TLabel', wraplength=770).pack(anchor='w', pady=(0, 18))

    def _connection_ui(self):
        f = self.connection_tab
        self._section(f, 'Tilslut din Hue Bridge',
                      'Klik på Find Bridge. Hvis den ikke dukker op, kan du skrive dens IP-adresse fra Hue-appen.')
        row = ttk.Frame(f)
        row.pack(anchor='w', fill='x', pady=8)
        ttk.Label(row, text='Bridge-IP').pack(side='left', padx=(0, 12))
        self.ip_var = tk.StringVar(value=self.config_data['ip'])
        ttk.Entry(row, textvariable=self.ip_var, width=22).pack(side='left', padx=(0, 8))
        ttk.Button(row, text='Find Bridge', command=self.discover).pack(side='left', padx=4)
        ttk.Button(row, text='Gem IP', command=self.save_ip).pack(side='left', padx=4)
        ttk.Button(row, text='Opdater pærer', command=self.refresh_lights).pack(side='left', padx=4)
        ttk.Label(f, text='Parring', style='Section.TLabel').pack(anchor='w', pady=(28, 8))
        ttk.Label(f, text='1. Tryk på den store, runde knap på din Hue Bridge.\n'
                          '2. Klik på “Par med Bridge” inden for cirka 30 sekunder.\n'
                          '3. Gå til fanen Pærer, og vælg de lys, du vil bruge.',
                  justify='left').pack(anchor='w', pady=(0, 18))
        ttk.Button(f, text='Par med Bridge', style='Accent.TButton', command=self.pair).pack(anchor='w')
        self.pair_var = tk.StringVar(value='Ikke parret' if not self.config_data['app_key'] else 'Tidligere parret – klar til at hente pærer')
        ttk.Label(f, textvariable=self.pair_var, style='Muted.TLabel').pack(anchor='w', pady=12)
        ttk.Label(f, text='Prøv lyset uden en Bridge',
                  style='Section.TLabel').pack(anchor='w', pady=(25, 7))
        ttk.Label(f, text='I demoen kan du se, hvordan lyset reagerer.',
                  style='Muted.TLabel', wraplength=770).pack(anchor='w', pady=(0, 10))
        self.demo_button_var = tk.StringVar()
        self.demo_status_var = tk.StringVar()
        self._update_demo_labels()
        ttk.Button(f, textvariable=self.demo_button_var, style='Accent.TButton',
                   command=self.toggle_demo).pack(anchor='w')
        if not self.bang_chaos:
            ttk.Label(f, textvariable=self.demo_status_var, style='Muted.TLabel').pack(anchor='w', pady=(8, 0))

    def _lights_ui(self):
        f = self.lights_tab
        self._section(f, 'Dine pærer',
                      'Sæt flueben ved de pærer, du vil bruge. Under Effekter kan du vælge en bestemt pære til hver hændelse.')
        self.light_tree = ttk.Treeview(f, columns=('selected', 'name', 'features'), show='headings', height=12)
        for col, label, width in [('selected', '✓', 65), ('name', 'Pære / enhed', 430), ('features', 'Understøtter', 290)]:
            self.light_tree.heading(col, text=label)
            self.light_tree.column(col, width=width, stretch=col != 'selected', anchor='center' if col == 'selected' else 'w')
        self.demo_preview_frame = ttk.Frame(f)
        self.demo_preview_frame.pack(fill='x', pady=(14, 0))
        ttk.Label(self.demo_preview_frame, text='LIVE DEMO – virtuelle pærer', style='Section.TLabel').pack(anchor='w', pady=(0, 8))
        self.preview_bulbs = {}
        tiles = ttk.Frame(self.demo_preview_frame)
        tiles.pack(fill='x')
        for light_id, name in DemoBridge._template:
            tile = tk.Frame(tiles, bg=PANEL, width=185, height=85)
            tile.pack(side='left', padx=(0, 10), fill='x', expand=True)
            tile.pack_propagate(False)
            face = tk.Canvas(tile, bg=PANEL, highlightthickness=0, height=43)
            face.pack(fill='x', pady=(8, 0))
            face.create_oval(72, 4, 108, 40, fill='#444444', outline='')
            name_label = tk.Label(tile, text=name.replace('Demo • ', ''), bg=PANEL, fg=FG,
                                  font=('Segoe UI', 10))
            name_label.pack()
            self.preview_bulbs[light_id] = face
        self.demo_preview_frame.pack_forget()
        self.light_tree.bind('<ButtonRelease-1>', self._light_click)
        self.light_tree.bind('<Double-1>', self._light_double)
        r = ttk.Frame(f)
        r.pack(fill='x', pady=15)
        ttk.Button(r, text='Vælg alle', command=lambda: self._select_all(True)).pack(side='left', padx=(0, 8))
        ttk.Button(r, text='Fravælg alle', command=lambda: self._select_all(False)).pack(side='left', padx=6)
        ttk.Button(r, text='Opdater fra Bridge', command=self.refresh_lights).pack(side='left', padx=6)
        self.selected_var = tk.StringVar(value='0 valgte pærer')
        ttk.Label(r, textvariable=self.selected_var, style='Muted.TLabel').pack(side='right')
        self.light_tree.pack(fill='both', expand=True)

    def _effects_ui(self):
        f = self.effects_tab
        self._section(f, 'Hvad skal lyset gøre?',
                      'Vælg en række, og prøv effekten med Test valgt, når du har gemt.')
        body = ttk.Frame(f)
        body.pack(fill='both', expand=True)
        left = ttk.Frame(body)
        left.pack(side='left', fill='both', expand=True, padx=(0, 20))
        right = ttk.Frame(body)
        right.pack(side='left', fill='y')
        self.effect_tree = ttk.Treeview(left, columns=('id', 'name', 'kind'), show='headings', height=11)
        if self.bang_chaos:
            self.effect_tree['displaycolumns'] = ('name', 'kind')
        for col, label, width in [('id', 'ID', 105), ('name', 'Effekt', 190), ('kind', 'Type', 150)]:
            self.effect_tree.heading(col, text=label)
            self.effect_tree.column(col, width=width, stretch=col == 'name')
        toolbar = ttk.Frame(left)
        toolbar.pack(fill='x', pady=(0, 8))
        ttk.Button(toolbar, text='+ Ny effekt', command=self.add_effect).pack(side='left', padx=(0, 6))
        self.delete_effect_button = ttk.Button(toolbar, text='Slet effekt', command=self.delete_effect)
        self.delete_effect_button.pack(side='left', padx=6)
        self.delete_effect_button.state(['disabled'])
        ttk.Button(toolbar, text='Test valgt', style='Accent.TButton', command=self.test_effect).pack(side='right')
        scrollbar = ttk.Scrollbar(left, orient='vertical', command=self.effect_tree.yview)
        scrollbar.pack(side='right', fill='y')
        self.effect_tree.configure(yscrollcommand=scrollbar.set)
        self.effect_tree.pack(fill='both', expand=True)
        self.effect_tree.bind('<<TreeviewSelect>>', self._effect_selected)
        self.effect_vars = {}
        def entry(label, key, width=24):
            var = tk.StringVar()
            self.effect_vars[key] = var
            row = ttk.Frame(right)
            row.pack(fill='x', pady=3)
            ttk.Label(row, text=label).pack(side='left', padx=(0, 9))
            field = ttk.Entry(row, textvariable=var, width=width)
            field.pack(side='right')
            return field
        if self.bang_chaos:
            self.effect_vars['name'] = tk.StringVar()
        else:
            entry('Navn', 'name')
        ttk.Label(right, text='Effekttype').pack(anchor='w', pady=(5, 3))
        self.effect_vars['kind'] = tk.StringVar()
        ttk.Combobox(right, state='readonly', textvariable=self.effect_vars['kind'],
                     values=EFFECT_TYPES, width=22).pack(anchor='w')
        if self.bang_chaos:
            self.effect_vars['color'] = tk.StringVar()
        else:
            entry('Farve', 'color', 10)
        color_row = ttk.Frame(right)
        color_row.pack(anchor='w', pady=5)
        self.color_button = ttk.Button(color_row, text='Vælg farve', command=self.choose_effect_appearance)
        self.color_button.pack(side='left')
        self.color_sample = tk.Label(color_row, width=3, bg=FIELD)
        self.color_sample.pack(side='left', padx=8)
        for key in ('kind', 'color'):
            self.effect_vars[key].trace_add('write', self._update_color_picker)
        entry('Varighed (sek.)', 'duration', 6)
        entry('Lysstyrke (%)', 'brightness', 6)
        self.temperature_entry = entry('Hvidtemperatur (K)', 'kelvin', 6)
        self.scene_ids = {'scene_id': '', 'demo_scene_id': ''}
        self.scene_names = {'scene_id': '', 'demo_scene_id': ''}
        entry('Pause før gentagelse (sek.)', 'cooldown', 6)
        if self.bang_chaos:
            ttk.Button(right, text='Vælg pærer til denne effekt', command=self.choose_effect_lights).pack(anchor='w', pady=(7, 0))
            self.effect_lights_text = tk.StringVar()
            ttk.Label(right, textvariable=self.effect_lights_text, style='Muted.TLabel',
                      wraplength=245).pack(anchor='w', pady=(3, 0))
        self.effect_enabled = tk.BooleanVar(value=True)
        if self.bang_chaos:
            self.effect_mode = ttk.Combobox(right, state='readonly', width=23)
            self.effect_mode.pack(anchor='w', pady=5)
        else:
            ttk.Checkbutton(right, text='Effekt aktiv', variable=self.effect_enabled).pack(anchor='w', pady=5)
        ttk.Button(right, text='Gem ændringer', style='Accent.TButton', command=self.save_effect).pack(fill='x', pady=6)
        self._reload_effect_list()

    def _streamer_ui(self):
        f = self.streamer_tab
        self._section(f, 'Kobl Twitch-kanalpoint til lyset',
                      'Streamer.bot sender GET direkte til dette program på samme computer. Ingen port forwarding og ingen Home Assistant.')
        ttk.Label(f, text='1. Vælg belønningen, du vil koble på', style='Section.TLabel').pack(anchor='w', pady=(0, 8))
        self.url_effect_var = tk.StringVar()
        self.effect_combo = ttk.Combobox(f, state='readonly', textvariable=self.url_effect_var, width=44)
        self.effect_combo.pack(anchor='w', pady=(0, 15))
        self.effect_combo.bind('<<ComboboxSelected>>', lambda _: self._update_url())
        ttk.Label(f, text='2. URL til Streamer.bot → Core → Network → Fetch URL', style='Section.TLabel').pack(anchor='w')
        urlrow = ttk.Frame(f)
        urlrow.pack(fill='x', pady=(8, 18))
        self.url_var = tk.StringVar()
        ttk.Entry(urlrow, textvariable=self.url_var, state='readonly').pack(side='left', fill='x', expand=True)
        ttk.Button(urlrow, text='Kopiér URL', command=lambda: self.copy(self.url_var.get())).pack(side='left', padx=10)
        ttk.Label(f, text='3. Tilføj følgende header i Fetch URL', style='Section.TLabel').pack(anchor='w')
        ttk.Label(f, text='Header-navn: X-Hue-Twitch-Token', style='Muted.TLabel').pack(anchor='w', pady=(8, 5))
        keyrow = ttk.Frame(f)
        keyrow.pack(fill='x', pady=(0, 18))
        self.token_var = tk.StringVar(value=self.config_data['access_token'])
        ttk.Entry(keyrow, textvariable=self.token_var, state='readonly', show='●').pack(side='left', fill='x', expand=True)
        ttk.Button(keyrow, text='Kopiér nøgle', command=lambda: self.copy(self.token_var.get())).pack(side='left', padx=10)
        ttk.Label(f, text='4. Trigger: Twitch → Channel Reward → Reward Redemption', style='Section.TLabel').pack(anchor='w')
        ttk.Label(f, text='Opret en Action for belønningen, vælg den tilsvarende Twitch-trigger, og tilføj Fetch URL\n'
                          'med URL + header. Sæt “Variable Name” til hueResult. Gentag for de andre belønninger.',
                  style='Muted.TLabel', justify='left').pack(anchor='w', pady=(7, 16))
        ttk.Button(f, text='Kopiér komplet opsætning', command=self.copy_setup).pack(anchor='w')
        ttk.Button(f, text='Test HTTP-forbindelsen uden Twitch', style='Accent.TButton',
                   command=self.test_http).pack(anchor='w', pady=(14, 0))
        ttk.Label(f, text='Vigtigt: Streamer.bot skal køre på samme Windows-PC som Hue Twitch Controller.\n'
                          'Adgangsnøglen må ikke vises på streamen eller deles offentligt.',
                  style='Muted.TLabel', justify='left').pack(anchor='w', pady=(21, 0))
        self._refresh_effect_combo()

    def _log_ui(self):
        f = self.log_tab
        self._section(f, 'Hændelser', 'Se hvilke lyseffekter der blev modtaget, kørt og gendannet.')
        self.log_text = tk.Text(f, bg=PANEL, fg=FG, insertbackground=FG, relief='flat', borderwidth=0,
                                font=('Consolas', 10), wrap='word', state='disabled', padx=12, pady=12)
        buttons = ttk.Frame(f)
        buttons.pack(fill='x', pady=(0, 10))
        ttk.Button(buttons, text='Stop effekt og ryd kø', command=self.engine.cancel).pack(side='left')
        ttk.Button(buttons, text='Ryd log', command=self.clear_log).pack(side='right')
        self.log_text.pack(fill='both', expand=True)

    def _background(self, operation, done):
        if self.busy:
            messagebox.showinfo('Arbejder', 'En Bridge-handling er allerede i gang.')
            return
        self.busy = True
        def worker():
            try:
                result = operation()
                self.events.put(('result', done, result, None))
            except Exception as e:
                self.events.put(('result', done, None, e))
        threading.Thread(target=worker, daemon=True).start()

    def _poll_events(self):
        try:
            while True:
                event = self.events.get_nowait()
                if event[0] == 'log':
                    self._show_log(event[1])
                elif event[0] == 'result':
                    _, done, value, error = event
                    self.busy = False
                    done(value, error)
                elif event[0] == 'update':
                    _, done, value, error = event
                    self.update_running = False
                    self.update_button.state(['!disabled'])
                    done(value, error)
        except queue.Empty:
            pass
        self._refresh_demo_preview()
        self.after(120, self._poll_events)

    def log(self, msg):
        from datetime import datetime
        self.events.put(('log', f"[{datetime.now().strftime('%H:%M:%S')}] {msg}"))

    def update_task(self, operation, done, text):
        if self.update_running:
            return
        self.update_running = True
        self.update_button.configure(text=text)
        self.update_button.state(['disabled'])

        def worker():
            try:
                self.events.put(('update', done, operation(), None))
            except Exception as error:
                self.events.put(('update', done, None, error))

        threading.Thread(target=worker, daemon=True).start()

    def check_for_updates(self, quiet=False):
        def completed(info, error):
            self.update_info = info
            self.update_button.configure(text='Opdater' if info else 'Søg efter opdatering')
            if error and not quiet:
                messagebox.showwarning('Opdatering', 'Kunne ikke tjekke efter en opdatering. Prøv igen senere.', parent=self)
            elif not info and not quiet:
                messagebox.showinfo('Opdatering', 'Du har den nyeste version.', parent=self)
        self.update_task(lambda: check_update(self.install_folder), completed, 'Tjekker …')

    def update_clicked(self):
        if not self.update_info:
            self.check_for_updates()
            return

        def completed(_, error):
            if error:
                self.update_button.configure(text='Opdater')
                messagebox.showerror('Opdatering', f'Kunne ikke installere opdateringen.\n{error}', parent=self)
                return
            self.update_info = None
            self.update_button.configure(text='Genstart for at opdatere')
            self.update_button.state(['disabled'])
            messagebox.showinfo('Opdateringen er hentet',
                                'Luk Bang Chaos og lysvinduet. Åbn derefter Start Bang Chaos med Hue igen.',
                                parent=self)

        self.update_task(lambda: install_update(self.install_folder, self.update_info), completed, 'Opdaterer …')

    def _show_log(self, msg):
        self.log_text.configure(state='normal')
        self.log_text.insert('end', msg + '\n')
        self.log_text.see('end')
        self.log_text.configure(state='disabled')

    def clear_log(self):
        self.log_text.configure(state='normal')
        self.log_text.delete('1.0', 'end')
        self.log_text.configure(state='disabled')

    def save_ip(self):
        if self.config_data.get('demo_mode'):
            messagebox.showinfo('Demo aktiv', 'Slå demo fra, før du gemmer Bridge-IP.')
            return
        try:
            ip = check_local_ip(self.ip_var.get())
            if ip != self.config_data['ip']:
                self.config_data['app_key'] = ''
                self.config_data['certificate_sha256'] = ''
                self.config_data['selected_ids'] = []
                self.lights = []
                self._reload_lights()
            self.config_data['ip'] = ip
            save_config(self.config_data)
            self.log('Bridge-IP gemt: ' + ip)
            self.status_var.set('● IP gemt')
        except Exception as e:
            messagebox.showerror('Bridge-IP', str(e))

    def _update_demo_labels(self):
        demo = self.config_data.get('demo_mode', False)
        self.demo_button_var.set('Slå demo fra – brug rigtig Bridge' if demo else 'Start demo uden Hue Bridge')
        self.demo_status_var.set('DEMO AKTIV: Ingen fysiske pærer styres.' if demo else 'Demo er slået fra.')

    def toggle_demo(self):
        entering = not self.config_data.get('demo_mode', False)
        self.engine.cancel()
        if entering:
            self.config_data['real_selected_ids'] = list(self.config_data['selected_ids'])
            self.config_data['selected_ids'] = [uid for uid, _ in DemoBridge._template]
        else:
            self.config_data['selected_ids'] = list(self.config_data.get('real_selected_ids', []))
        self.config_data['demo_mode'] = entering
        save_config(self.config_data)
        self._update_demo_labels()
        self._refresh_demo_preview()
        if entering or self.config_data.get('app_key'):
            self.refresh_lights()
        else:
            self.lights = []
            self._reload_lights()
            self.status_var.set('● Klar til at parre Hue Bridge')
        self.log('Demo-tilstand ' + ('aktiveret: ingen fysisk Bridge bruges' if entering else 'deaktiveret'))

    def _refresh_demo_preview(self):
        demo = self.config_data.get('demo_mode', False)
        if not hasattr(self, 'demo_preview_frame'):
            return
        if demo and not self.demo_preview_frame.winfo_manager():
            self.demo_preview_frame.pack(fill='x', pady=(14, 0), before=self.light_tree)
        elif not demo and self.demo_preview_frame.winfo_manager():
            self.demo_preview_frame.pack_forget()
        if not demo:
            self.demo_render_state = None
            return
        lights = DemoBridge().lights()
        state = tuple((l['id'], l['on']['on'], l['dimming']['brightness'], l['_preview_hex']) for l in lights)
        if state == self.demo_render_state:
            return
        self.demo_render_state = state
        for l in lights:
            canvas = self.preview_bulbs[l['id']]
            canvas.itemconfigure(1, fill=l['_preview_hex'] if l['on']['on'] else '#282E3A')

    def test_http(self):
        effect_id = self.url_effect_var.get()
        if not effect_id:
            return
        url = self.url_var.get()
        token = self.config_data['access_token']
        def call():
            req = Request(url, headers={'X-Hue-Twitch-Token': token})
            try:
                with urlopen(req, timeout=5) as r:
                    return f'HTTP {r.status}: {r.read().decode("utf-8")}'
            except HTTPError as e:
                return f'HTTP {e.code}: {e.read().decode("utf-8")}'
        self._background(call, self._http_done)

    def _http_done(self, value, error):
        self.tabs.select(self.log_tab)
        self.log('Lokal HTTP-test: ' + (str(error) if error else value))

    def discover(self):
        if self.config_data.get('demo_mode'):
            messagebox.showinfo('Demo aktiv', 'Slå demo fra, før du søger efter Hue Bridge.')
            return
        self.status_var.set('● Søger efter Bridge...')
        self._background(discover_bridge, self._found)

    def _found(self, value, error):
        if error:
            self.status_var.set('● IP skal indtastes manuelt')
            messagebox.showwarning('Find Bridge', str(error))
        else:
            self.ip_var.set(value)
            self.save_ip()
            messagebox.showinfo('Bridge fundet', f'Fandt mulig Hue Bridge på {value}.\nTryk nu på Bridge-knappen og vælg Par.')

    def pair(self):
        if self.config_data.get('demo_mode'):
            messagebox.showinfo('Demo aktiv', 'Slå demo fra, før du parrer Hue Bridge.')
            return
        try:
            ip = check_local_ip(self.ip_var.get())
        except ValueError as e:
            messagebox.showerror('Bridge-IP', str(e))
            return
        self.status_var.set('● Afventer Hue-knappen (op til 32 sek.)')
        self.pair_var.set('Tryk på den runde knap på din Hue Bridge ...')
        self._background(lambda: HueBridge(ip).pair(), lambda value, error: self._paired(ip, value, error))

    def _paired(self, ip, value, error):
        if error:
            self.status_var.set('● Parring mislykkedes')
            self.pair_var.set(str(error))
            self.log('Parring mislykkedes: ' + str(error))
            messagebox.showerror('Parring', str(error))
            return
        key, fingerprint = value
        if ip != self.config_data['ip']:
            self.config_data['selected_ids'] = []
        self.config_data['ip'] = ip
        self.config_data['app_key'] = key
        self.config_data['certificate_sha256'] = fingerprint
        save_config(self.config_data)
        self.status_var.set('● Hue Bridge forbundet')
        self.pair_var.set('Parret og klar – gå til fanen Pærer')
        self.log('Hue Bridge er tilsluttet.')
        self.refresh_lights()

    def refresh_lights(self):
        if self.config_data.get('demo_mode'):
            self._got_lights(DemoBridge().lights(), None)
            return
        cfg = self.config_data
        if not cfg.get('app_key') or not cfg.get('certificate_sha256'):
            messagebox.showinfo('Parring mangler', 'Par Hue Bridge i den første fane, før du henter pærer.')
            return
        self.status_var.set('● Henter pærer...')
        self._background(lambda: HueBridge(cfg['ip'], cfg['app_key'], cfg['certificate_sha256']).lights(), self._got_lights)

    def _got_lights(self, value, error):
        if error:
            self.status_var.set('● Bridge-forbindelse fejlede')
            self.log('Kunne ikke hente pærer: ' + str(error))
            messagebox.showerror('Hue Bridge', str(error))
            return
        self.lights = value
        self._reload_lights()
        if self.config_data.get('demo_mode'):
            self.status_var.set(f'● DEMO · {len(value)} virtuelle pærer')
            self.log(f'Indlæst {len(value)} virtuelle pærer – ingen fysisk Bridge')
        else:
            self.status_var.set(f'● Hue forbundet · {len(value)} pærer')
            self.log(f'Indlæst {len(value)} pærer fra Hue Bridge')

    def _reload_lights(self):
        self.light_tree.delete(*self.light_tree.get_children())
        selected = set(self.config_data['selected_ids'])
        for light in self.lights:
            features = ['Tænd/sluk']
            if 'color' in light:
                features.append('Farver')
            if 'color_temperature' in light:
                features.append('Hvidtoner')
            self.light_tree.insert('', 'end', iid=light['id'],
                values=('☑' if light['id'] in selected else '☐', light['_display_name'], ', '.join(features)))
        self.selected_var.set(f'{len(selected)} valgte pærer')
        self._update_effect_lights_text()

    def _light_click(self, event):
        if self.light_tree.identify_column(event.x) == '#1':
            self._toggle_selected_row(self.light_tree.identify_row(event.y))

    def _light_double(self, event):
        if self.light_tree.identify_column(event.x) != '#1':
            self._toggle_selected_row(self.light_tree.identify_row(event.y))

    def _toggle_selected_row(self, light_id):
        if not light_id:
            return
        selected = set(self.config_data['selected_ids'])
        if light_id in selected:
            selected.remove(light_id)
        else:
            selected.add(light_id)
        self.config_data['selected_ids'] = sorted(selected)
        save_config(self.config_data)
        self._reload_lights()

    def _select_all(self, enabled):
        self.config_data['selected_ids'] = [l['id'] for l in self.lights] if enabled else []
        save_config(self.config_data)
        self._reload_lights()

    def _reload_effect_list(self, select=None):
        self.effect_tree.delete(*self.effect_tree.get_children())
        effects = self.config_data['effects']
        if self.bang_chaos:
            ids = [key for key in BANG_EVENTS if key in effects]
            built_in = default_effects()
            ids.extend(key for key in effects if key not in built_in and key not in BANG_EVENTS)
        else:
            ids = sorted(effects)
        for effect_id in ids:
            effect = effects[effect_id]
            self.effect_tree.insert('', 'end', iid=effect_id,
                                    values=(effect_id, BANG_EVENTS.get(effect_id, effect.get('name')) if self.bang_chaos else effect.get('name'),
                                            'Fælles effekt' if effect.get('inherit_level') else
                                            effect.get('kind') if effect.get('enabled', True) else 'Gør ingenting'))
        if ids:
            selected = select if select in ids else ids[0]
            self.effect_tree.selection_set(selected)
            self.effect_tree.focus(selected)
            self.effect_tree.see(selected)
            self._effect_selected()
        self._refresh_effect_combo()

    def _effect_selected(self, _=None):
        selection = self.effect_tree.selection()
        if not selection:
            return
        self.effect_id = selection[0]
        can_delete = not self.bang_chaos or self.effect_id not in BANG_EVENTS
        self.delete_effect_button.state(['!disabled'] if can_delete else ['disabled'])
        data = self.config_data['effects'].get(self.effect_id)
        if not data:
            return
        for key, var in self.effect_vars.items():
            var.set(str(data.get(key, 2500 if key == 'kelvin' else '')))
        for key in self.scene_ids:
            self.scene_ids[key] = data.get(key, '')
            self.scene_names[key] = data.get(key + '_name', '')
        self._update_color_picker()
        self.effect_enabled.set(data.get('enabled', True))
        if self.bang_chaos:
            modes = ['Kør effekten', 'Gør ingenting']
            if self.effect_id.startswith('level-') and self.effect_id in BANG_EVENTS:
                modes.append('Brug fælles effekt')
            self.effect_mode.configure(values=modes)
            self.effect_mode.set('Brug fælles effekt' if data.get('inherit_level') else
                                 'Kør effekten' if data.get('enabled', True) else 'Gør ingenting')
        self._update_effect_lights_text()

    def choose_color(self):
        value = self.effect_vars['color']
        initial = value.get()
        _, color = colorchooser.askcolor(
            color=initial if re.fullmatch(r'#[0-9a-fA-F]{6}', initial) else '#FFFFFF',
            parent=self, title='Vælg farve')
        if color:
            value.set(color.upper())

    def _update_color_picker(self, *_):
        color = self.effect_vars['color'].get()
        kind = self.effect_vars['kind'].get()
        active = kind in ('Farve', 'Blink i valgt farve')
        self.color_button.state(['!disabled'] if active or kind == 'Hue-scene' else ['disabled'])
        title = 'Vælg farve'
        if kind == 'Hue-scene':
            title = self.scene_names.get(self._scene_key()) or 'Vælg Hue-scene'
        self.color_button.configure(text=title[:28])
        self.color_sample.configure(bg=color if active and re.fullmatch(r'#[0-9a-fA-F]{6}', color) else FIELD)
        self.temperature_entry.state(['!disabled'] if kind == 'Varm hvid' else ['disabled'])

    def _scene_key(self):
        return 'demo_scene_id' if self.config_data.get('demo_mode') else 'scene_id'

    def choose_effect_appearance(self):
        if self.effect_vars['kind'].get() != 'Hue-scene':
            self.choose_color()
            return
        cfg = self.config_data
        if cfg.get('demo_mode'):
            self._show_scenes(DemoBridge().scenes(), None)
        elif cfg.get('app_key') and cfg.get('certificate_sha256'):
            bridge = HueBridge(cfg['ip'], cfg['app_key'], cfg['certificate_sha256'])
            effect_id = self.effect_id
            def show_if_selected(scenes, error):
                if self.effect_id == effect_id and not self.config_data.get('demo_mode'):
                    self._show_scenes(scenes, error)
            self._background(bridge.scenes, show_if_selected)
        else:
            messagebox.showinfo('Hue-scener', 'Par din Hue Bridge først, eller prøv demoen.')

    def _show_scenes(self, scenes, error):
        if error:
            messagebox.showerror('Kunne ikke hente Hue-scener', str(error))
            return
        scenes = sorted(scenes, key=lambda scene: scene.get('metadata', {}).get('name', '').casefold())
        if not scenes:
            messagebox.showinfo('Hue-scener', 'Opret en scene i Hue-appen, og prøv igen.')
            return
        popup = tk.Toplevel(self)
        popup.title('Vælg Hue-scene')
        popup.transient(self)
        popup.grab_set()
        pane = ttk.Frame(popup, padding=18)
        pane.pack(fill='both', expand=True)
        choices = tk.Listbox(pane, height=min(len(scenes), 10), width=40, exportselection=False)
        choices.pack(fill='both', expand=True, pady=(0, 8))
        key = self._scene_key()
        for index, scene in enumerate(scenes):
            choices.insert('end', scene.get('metadata', {}).get('name') or 'Scene uden navn')
            if scene['id'] == self.scene_ids[key]:
                choices.selection_set(index)

        def select():
            if choices.curselection():
                index = choices.curselection()[0]
                self.scene_ids[key] = scenes[index]['id']
                self.scene_names[key] = choices.get(index)
                self._update_color_picker()
                popup.destroy()

        ttk.Button(pane, text='Brug denne scene', command=select, style='Accent.TButton').pack(anchor='w')
        popup.bind('<Return>', lambda _: select())
        self._center_popup(popup)

    def _effect_light_key(self):
        return 'demo_light_ids' if self.config_data.get('demo_mode') else 'light_ids'

    def _update_effect_lights_text(self):
        if not hasattr(self, 'effect_lights_text'):
            return
        effect = self.config_data['effects'].get(self.effect_id, {})
        targets = effect.get(self._effect_light_key())
        selected = set(self.config_data['selected_ids'])
        if not isinstance(targets, list):
            self.effect_lights_text.set('Bruger alle pærer med flueben')
        else:
            names = [light['_display_name'] for light in self.lights
                     if light['id'] in selected and light['id'] in targets]
            self.effect_lights_text.set(', '.join(names) if names else 'Ingen af effektens pærer er valgt')

    def choose_effect_lights(self):
        effect = self.config_data['effects'].get(self.effect_id)
        if effect is None:
            return
        selected = set(self.config_data['selected_ids'])
        lights = [light for light in self.lights if light['id'] in selected]
        if not lights:
            messagebox.showinfo('Vælg pærer', 'Gå til fanen Pærer, og sæt først flueben ved de lys, du vil bruge.')
            return
        key = self._effect_light_key()
        saved = effect.get(key)
        popup = tk.Toplevel(self)
        popup.title(BANG_EVENTS.get(self.effect_id, effect['name']) + ' – vælg pærer')
        popup.configure(bg=BG)
        popup.transient(self)
        popup.grab_set()
        pane = ttk.Frame(popup, padding=18)
        pane.pack(fill='both', expand=True)
        ttk.Label(pane, text='Klik på de lys, der skal reagere.').pack(anchor='w')
        choices = tk.Listbox(pane, selectmode=tk.MULTIPLE, exportselection=False,
                             height=min(len(lights), 9), width=42)
        choices.pack(fill='both', expand=True, pady=10)
        for index, light in enumerate(lights):
            choices.insert('end', light['_display_name'])
            if not isinstance(saved, list) or light['id'] in saved:
                choices.selection_set(index)

        def save_selection(use_all=False):
            if use_all:
                effect.pop(key, None)
            else:
                targets = [lights[index]['id'] for index in choices.curselection()]
                if not targets:
                    messagebox.showinfo('Vælg mindst én pære', 'Klik på den pære, der skal reagere.', parent=popup)
                    return
                effect[key] = targets
            save_config(self.config_data)
            self._update_effect_lights_text()
            popup.destroy()

        ttk.Button(pane, text='Gem valgte pærer', command=save_selection,
                   style='Accent.TButton').pack(anchor='w', pady=4)
        ttk.Button(pane, text='Brug alle pærer med flueben',
                   command=lambda: save_selection(True)).pack(anchor='w')
        self._center_popup(popup)

    def _center_popup(self, popup):
        popup.update_idletasks()
        x = self.winfo_rootx() + (self.winfo_width() - popup.winfo_width()) // 2
        y = self.winfo_rooty() + (self.winfo_height() - popup.winfo_height()) // 2
        popup.geometry(f'+{max(0, x)}+{max(0, y)}')
        popup.bind('<Escape>', lambda _: popup.destroy())

    def save_effect(self):
        if not self.effect_id:
            return
        try:
            data = {k: var.get() for k, var in self.effect_vars.items()}
            data['enabled'] = self.effect_enabled.get()
            if self.bang_chaos:
                data['enabled'] = self.effect_mode.get() == 'Kør effekten'
                data['inherit_level'] = self.effect_mode.get() == 'Brug fælles effekt'
            if data['enabled'] and data['kind'] == 'Hue-scene' and not self.scene_ids[self._scene_key()]:
                messagebox.showinfo('Hue-scene', 'Vælg en scene, før du gemmer effekten.')
                return
            data.update(self.scene_ids)
            data.update({key + '_name': value for key, value in self.scene_names.items()})
            validated_effect(data)
            self.config_data['effects'][self.effect_id].update(data)
            save_config(self.config_data)
            self._reload_effect_list(self.effect_id)
            self.log('Gemt effekt: ' + self.effect_id)
        except Exception as e:
            messagebox.showerror('Ugyldig effekt', str(e))

    def add_effect(self):
        popup = tk.Toplevel(self)
        popup.title('Ny effekt')
        popup.configure(bg=BG)
        popup.geometry('355x170')
        popup.transient(self)
        popup.grab_set()
        prompt = 'Hvad skal effekten hedde?' if self.bang_chaos else 'Unikt effekt-ID (a-z, 0-9, _ eller -)'
        ttk.Label(popup, text=prompt).pack(padx=16, pady=(16, 7), anchor='w')
        value = tk.StringVar()
        e = ttk.Entry(popup, textvariable=value, width=28)
        e.pack(padx=16, anchor='w')
        e.focus_set()
        def create():
            name = value.get().strip()
            if self.bang_chaos:
                if not name:
                    messagebox.showerror('Ny effekt', 'Skriv et navn til effekten.', parent=popup)
                    return
                ident = 'effekt-' + uuid4().hex[:24]
            else:
                ident = name.lower()
                name = ident
            if not re.fullmatch(r'[a-z0-9_-]{1,32}', ident) or ident in self.config_data['effects']:
                messagebox.showerror('Effekt-ID', 'Brug et nyt ID med a-z, 0-9, _ og - (maks. 32 tegn).', parent=popup)
                return
            self.config_data['effects'][ident] = dict(name=name, kind='Farve', color='#FF8800', duration=8,
                                                      brightness=80, cooldown=15, enabled=True)
            save_config(self.config_data)
            self._reload_effect_list(ident)
            popup.destroy()
        ttk.Button(popup, text='Opret effekt', style='Accent.TButton', command=create).pack(padx=16, pady=14, anchor='w')
        popup.bind('<Return>', lambda _: create())
        self._center_popup(popup)

    def delete_effect(self):
        if not self.effect_id:
            return
        if self.bang_chaos and self.effect_id in BANG_EVENTS:
            return
        name = self.config_data['effects'][self.effect_id]['name']
        prompt = f'Vil du slette “{name}”?'
        if not self.bang_chaos:
            prompt += '\nHvis en Streamer.bot-handling bruger effekten, holder den op med at virke.'
        if messagebox.askyesno('Slet effekt', prompt, parent=self):
            self.config_data['effects'].pop(self.effect_id, None)
            save_config(self.config_data)
            self.effect_id = None
            self._reload_effect_list()

    def test_effect(self):
        if not self.effect_id:
            return
        code, msg = self.engine.enqueue(self.effect_id, bypass_cooldown=True)
        self.log('Manuel test: ' + msg)
        if code != 202:
            messagebox.showwarning('Kan ikke teste', msg)

    def _refresh_effect_combo(self):
        if not hasattr(self, 'effect_combo'):
            return
        ids = list(sorted(self.config_data['effects']))
        self.effect_combo['values'] = ids
        if self.url_effect_var.get() not in ids:
            self.url_effect_var.set(ids[0] if ids else '')
        self._update_url()

    def _update_url(self):
        ident = self.url_effect_var.get()
        self.url_var.set(f"http://127.0.0.1:{self.config_data['port']}/trigger?effect={quote(ident)}" if ident else '')

    def copy(self, text):
        self.clipboard_clear()
        self.clipboard_append(text)
        self.update_idletasks()
        self.status_var.set('● Kopieret til udklipsholder')

    def copy_setup(self):
        content = (f"Streamer.bot → Actions → New Action → Twitch → Channel Reward → Reward Redemption\n"
                   f"Sub-Action: Core → Network → Fetch URL\n"
                   f"URL: {self.url_var.get()}\n"
                   f"Variable Name: hueResult\n"
                   f"Header: X-Hue-Twitch-Token\n"
                   f"Value: {self.config_data['access_token']}\n"
                   f"Parse result as JSON: valgfrit\n"
                   f"Test: Brug 'Test valgt' under Effekter først.\n"
                   f"Bemærk: Dette indeholder din hemmelige lokale nøgle. Del ikke indholdet.")
        self.copy(content)

    def _exit(self):
        if self.update_running and self.update_info:
            messagebox.showinfo('Opdaterer', 'Vent, til opdateringen er færdig, før du lukker lysvinduet.', parent=self)
            return
        self.status_var.set('● Lukker og gendanner lys...')
        self.update_idletasks()
        self.controller.stop()
        self.engine.shutdown()
        self.destroy()


if __name__ == '__main__':
    App().mainloop()
